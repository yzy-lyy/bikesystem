/*
 * @Author: your name
 * @Date: 2021-06-13 15:23:51
 * @LastEditTime: 2021-06-15 21:29:23
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \BikeData\insert.js
 */
//将数据插入数据库
const fs = require('fs');
const sql = require('mssql');
//连接数据库
const sqlConfig = {
    user:'sa',
    password:'yzy771595507',
    database:'Bike',
    server:'localhost',
    port:1433,
    pool:{
        max: 10,
        min: 0,
        idleTimeoutMillis: 3000
    },
    options: {
        encrypt: false, // for azure
    }
}
// sql.connect(sqlConfig).then(()=>{
//     return  sql.query(`select * from Users`)
// }).then(result => {
//     console.log(result)
// })
sql.on('error',err=>{
    if(err){
        console.log(err)
    }
})
// try {
//     const data = fs.readFileSync('./data/DataUser.json', 'utf8');
//     // parse JSON string to JSON object
//     const config = eval("("+data+")")
//     for(let i=0;i<100;i++){
//         console.log("-----保存到第"+i+"条数据-----------")
//         sql.connect(sqlConfig).then(()=>{
//             let name = config[i].user_name
//             let gender = config[i].gender
//             let type = config[i].uesr_type
//             let from_station = config[i].from_station_name
//             let to_station = config[i].to_station_name
//             let year = config[i].year_start
//             let day = config[i].day_start
//             let month = config[i].month_start
//             let during = config[i].trip_duration
//             let time_start = config[i].start_time
//             let time_stop = config[i].stop_time
//             let hour_start = config[i].hour_start
//             let hour_stop = config[i].hour_stop
//             return sql.query(`INSERT INTO Customers VALUES (
//                 ${i},${"'"+name+"'"},${"'"+gender+"'"},${"'"+type+"'"},${"'"+from_station+"'"},${"'"+to_station+"'"},${year},${month},${day},${during},${"'"+time_start+"'"},${"'"+time_stop+"'"},${hour_start},${hour_stop}
//             )`)
//         })
//         .then(result => {
//             sql.connect(sqlConfig).then(()=>{
//                 return sql.query(`select * from Customers`)
//             }).then(result => {
//                 console.log(result)
//             })
//         })
//     }

// } catch (err) {
//     console.log(`Error reading file from disk: ${err}`);
// }
try {
    const data = fs.readFileSync('./data/dataStation.json', 'utf8');
    // parse JSON string to JSON object
    const config = eval("("+data+")")
    for(let i=0;i<config.length;i++){
        console.log("-----保存到第"+i+"条数据-----------")
        sql.connect(sqlConfig).then(()=>{
            let Cid = parseInt(config[i].Cid)
            let Cnumber = parseInt(config[i].Cnumber)
            let Cname = config[i].Cname
            let Day = parseInt(config[i].Day)
            let dayNum = parseInt(config[i].dayNum)
            return sql.query(`INSERT INTO Station VALUES (
                ${Cid},${Cnumber},${"'"+Cname+"'"},${Day},${dayNum}
            )`)
        })
        .then(result => {
            console.log("successful")
        })
    }

} catch (err) {
    console.log(`Error reading file from disk: ${err}`);
}

// sql.connect(sqlConfig).then(()=>{
//     return  sql.query(`select * from Customers where Cid=10000`)
// }).then(result => {
//     console.log(result)
// })